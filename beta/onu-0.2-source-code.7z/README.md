
**Onu** is a fast, minimalist browser designed to stay under **10 MB** while remaining expressive, playful, and powerful — ideal for low‑end devices and lightweight systems.

---


## 📦 Download

- 🔗 **[Download Onu Beta (.deb)](https://github.com/zynomon/onu/raw/release/beta/onu-0.2.deb)**

---
i will update it tomorrow;
---

## 📂 More Screenshots

<details>
<summary><b>Load More</b> <span style="font-size:14px;">(click to expand)</span></summary>

## 🖼️ Preview

<div align="center">

![preview](https://github.com/user-attachments/assets/6fefa72e-38dc-4544-ad8d-9ed2f2edf685)
![prev](https://github.com/user-attachments/assets/6eeda817-45f7-460a-9ec8-393bf5f26d9c)
![VirtualBoxVM_LivCy2ZifW](https://github.com/user-attachments/assets/9900ea53-1da0-48db-a591-6d5cda5d343d)

<img width="1440" alt="stuff" src="https://github.com/user-attachments/assets/ffa3fd30-e5fe-4e90-b344-f89a69439294" />
<img width="1440" alt="set" src="https://github.com/user-attachments/assets/d4338294-596f-4aaf-b9c1-fefce032aa5d" />
<img width="1440" alt="set 2" src="https://github.com/user-attachments/assets/774a84dc-5cf9-4c4f-90ff-6ebc5fa6b831" />

![installing](https://github.com/user-attachments/assets/fccfeb20-741d-4bc1-a44f-b37880fc9c39)

<img width="1440" alt="home" src="https://github.com/user-attachments/assets/ac924a96-73e9-4cfd-b5ae-185cff931423" />
<img width="714" alt="game" src="https://github.com/user-attachments/assets/70b0bdce-719c-4b18-a21e-38c17caf144c" />
![gameplay](https://github.com/user-attachments/assets/cf97d488-927d-4461-8e68-a0d7913e9aeb)

</div>


</details>

---

